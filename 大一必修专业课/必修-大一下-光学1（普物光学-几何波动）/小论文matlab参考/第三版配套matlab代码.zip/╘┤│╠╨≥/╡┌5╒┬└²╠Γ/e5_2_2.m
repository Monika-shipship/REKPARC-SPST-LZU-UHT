I=imread('E:\hua1.jpg');
figure
imshow(I,200);
figure
imshow(I,[100,200]);
