T=[2 3 1 0 4 5];
poly2sym(T)
