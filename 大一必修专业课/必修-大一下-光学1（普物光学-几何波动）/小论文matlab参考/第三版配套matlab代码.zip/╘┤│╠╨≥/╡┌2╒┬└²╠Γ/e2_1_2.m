A=[1 3;2 4];
B=[0 4;3 2];
C=(A<=B),
D=(A==B),
E=A&B,
F=xor(A,B)
