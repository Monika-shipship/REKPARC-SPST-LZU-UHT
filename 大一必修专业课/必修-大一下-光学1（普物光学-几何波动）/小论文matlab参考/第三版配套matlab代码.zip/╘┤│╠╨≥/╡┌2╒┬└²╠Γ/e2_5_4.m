T=conv(p1,p2);
poly2sym(T)
