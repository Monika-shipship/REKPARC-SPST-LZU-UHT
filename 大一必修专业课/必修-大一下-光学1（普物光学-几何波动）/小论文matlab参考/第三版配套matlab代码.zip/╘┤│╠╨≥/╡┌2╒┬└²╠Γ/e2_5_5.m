p1=[3 0 2 -5];
p2=[5 2];
[T r]=deconv(p1,p2)
