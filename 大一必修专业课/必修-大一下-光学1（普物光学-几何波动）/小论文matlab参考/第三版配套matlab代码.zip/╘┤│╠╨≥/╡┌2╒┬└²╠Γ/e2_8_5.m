sum=0;
for i=1:1:100
sum=sum+i��
end
sum


sum=0;
i=1;
while (i<=100)
sum=sum+i;
i=i+1;
end
  sum
