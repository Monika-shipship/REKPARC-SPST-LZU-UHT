f1=dsolve('Dy+3*x*y=x*exp(-x^2)', 'x'),simplify(f1)
f2=dsolve('D2y+2*Dy+exp(x)=0', 'x'),simplify(f2)
