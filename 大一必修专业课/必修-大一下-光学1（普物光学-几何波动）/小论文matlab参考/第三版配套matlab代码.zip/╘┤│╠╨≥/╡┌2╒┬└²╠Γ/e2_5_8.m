p1=[3 0 2 -5];
h=roots(p1)
