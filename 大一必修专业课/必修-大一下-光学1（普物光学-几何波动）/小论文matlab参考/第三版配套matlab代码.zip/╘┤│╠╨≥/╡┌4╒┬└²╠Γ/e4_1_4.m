x=-2:0.01:2; 
y=sign(x); 
plot(x,y,'k','LineWidth',2) 
axis([-2 2 -1.1 1.1]) 
xlabel('x');  ylabel('sgn(x)')
